package com.zensar.component;

import org.springframework.stereotype.Component;

@Component
public class calculatorImp1 implements calculatorInterface{

	
	public int add(int cal1, int cal2) {
		int cal3=cal1+cal2;
	
		return cal3;
	}

	
	/*
	 * public int add(int cal1, int cal2, int cal3) {
	 * 
	 * return 0; }
	 */
	
}
