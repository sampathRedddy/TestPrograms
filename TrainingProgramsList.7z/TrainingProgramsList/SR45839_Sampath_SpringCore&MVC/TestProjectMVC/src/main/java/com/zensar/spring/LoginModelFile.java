package com.zensar.spring;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class LoginModelFile {

	 @Size (min = 2)
	 @NotNull
	 @NotEmpty
	 @Email
	private String loginID;
	 
	 @Size (min = 2)
	 @NotNull
	 @NotEmpty
	 @Pattern(regexp="[a-zA-Z0-9_.]*")
	private String password;
	 
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	public String getMessage(String id)
	{
		return id;
		
	}
	
	
}
