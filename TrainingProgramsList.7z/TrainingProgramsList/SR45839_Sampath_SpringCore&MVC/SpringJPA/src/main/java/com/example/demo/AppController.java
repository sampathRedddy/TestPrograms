package com.example.demo;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {
	
	@Autowired(required=true)
	private TopicsService topicsservice;
	
	
    @RequestMapping("/hello")
	public String display()
	{
	return "The";	
	}
	
    @RequestMapping("/topics")
    public List<Topics> getTopics()
    {
    	return topicsservice.getAllTopics();
    }
    
    @RequestMapping("/topics/{id}")
    public Topics getTopicID(@PathVariable String id)
    {
    	return topicsservice.getByID(id);
    }
    
    @RequestMapping(method=RequestMethod.POST,value="/topics" )
    public void addTopics(@RequestBody  Topics topic)
    {
    	 topicsservice.addTopics(topic);
    }
    
    @RequestMapping(method=RequestMethod.PUT,value="/topics/{id}")
    public void updateTopics(@RequestBody  Topics topic,@PathVariable String id)
    {
    	 topicsservice.updateTopics(id,topic);
    }
    
    @RequestMapping(method=RequestMethod.DELETE,value="/topics/{id}")
    public void deleteTopics(@RequestBody  Topics topic,@PathVariable String id)
    {
    	 topicsservice.deleteTopics(id,topic);
    }
}
