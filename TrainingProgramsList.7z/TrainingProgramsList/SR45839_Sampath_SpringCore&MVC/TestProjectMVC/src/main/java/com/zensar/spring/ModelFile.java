package com.zensar.spring;

import org.springframework.stereotype.Component;

@Component
public class ModelFile {

	public String getDisplay(String name, String pass)
	{
		
		return name+""+pass;
	}
}
