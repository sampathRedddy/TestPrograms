package com;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetofSubsetinjava {

	public static void main(String[] args) {
int [] a={1,2,3};
		
		Set <Integer> list1=new HashSet<Integer>();
		for(int i=0;i<a.length;i++)
		{
			list1.add(a[i]);
		}
		
		
		System.out.println(powerSet(list1));

	}
	public static Set<Set<Integer>> powerSet(Set<Integer> list2 )
	{
		Set<Set<Integer>> list3=new HashSet<Set<Integer>>();
		if(list2.isEmpty())
		{
			list3.add(new HashSet<Integer>());
			return list3;
		}
		List<Integer> listA=new ArrayList<Integer>(list2);
		int head=listA.get(0);
		Set<Integer> rest=new HashSet<Integer>(listA.subList(1, listA.size()));
		for(Set<Integer> set1:powerSet(rest))
		{
			Set<Integer>newset=new HashSet<Integer>();
			newset.add(head);
			newset.addAll(set1);
			list3.add(newset);
			list3.add(set1);
			
			
		}
		return list3;
		
	}

}
