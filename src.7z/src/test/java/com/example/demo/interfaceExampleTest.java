package com.example.demo;

import static org.junit.Assert.*;

import org.junit.Test;

public class interfaceExampleTest {

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

	@Test
	public void testDisplay() {
		fail("Not yet implemented");
	}

}
