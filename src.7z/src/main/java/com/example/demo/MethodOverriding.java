package com.example.demo;


class superClass1
{
	 public static void display(String i)
	 {
		 System.out.println("super class method"+i);
	 }
	 public static void display(int i)
	 {
		 System.out.println("super class method"+i);
	 }
	}
public class MethodOverriding extends superClass1{
	 public  void display(Object s)
	 {
		 System.out.println("sub class method"+s);
		// return "sampath";
	 }
	public static void main(String[] args) {
		
		superClass1 obj=new MethodOverriding();
		obj.display(null);
	}
	}