package com.example.demo;


public class ThreadFile  extends Thread{
public void run()
{
	System.out.println("run method"+Thread.currentThread().getId());
	}
	public static void main(String arg[])
	{
	Thread t1=new Thread(new ThreadFile());
	t1.start();
	System.out.println("Main Method");
	Thread t2=new Thread(new ThreadFile());
	t2.start();
	System.out.println("===========");
	
	ThreadFile obj=new ThreadFile();
	obj.start();
	ThreadFile obj1=new ThreadFile();
	obj1.start();
	
	
	ThreadFile obj2=new ThreadFile();
	ThreadFile obj3=new ThreadFile();
	System.out.println(obj2.hashCode()+"========"+obj3.hashCode());
	System.out.println("equals ::::::"+obj2.equals(obj3));
	
	}
}
