package com.ibm;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Permutationofstring {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String s1=sc.next();
		System.out.println(permutate(s1));

	}
	public static Set<String> permutate(String s1)
	{
		Set<String> m1=new HashSet<String>();
		if(s1==null)
		{
			return null;
		}
		if(s1.length()==0)
		{
			m1.add(" ");
			return m1;
		}
		char head=s1.charAt(0);
		String rem=s1.substring(1);
		Set<String> m2=permutate(rem);
		for(String s2:m2)
		{
			for(int i=0;i<s2.length();i++)
			{
				m1.add(permutecalculation(i,s2,head));
			}
		}
		return m1;
		
	}
	public static String permutecalculation(int i,String s2,char k)
	{
		String first=s2.substring(0,i);
		String last=s2.substring(i);
		return first+k+last;
		
	}

}
