package com.zensar.autowire;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanFile {

	
    @Bean(name="profile")	
	public Profile getProfile()
	{
		return new Profile();
	}
    @Bean(name="student")	
   	public Student getProfile1()
   	{
   		return new Student();
   	}
    @Bean(name="person")	
   	public Person getProfile12()
   	{
    	System.out.println("person bean ::::::::::::");
   		return new Person();
   	}
    @Bean(name="person1")	
   	public Person getProfile123()
   	{
    	
    String s="sampath reddy";
    Person obj=new Person();
   
    obj.setPersonProperty(s);
    
    System.out.println("object is :::::::::::"+obj.toString());
   		return obj;
   	}
}
