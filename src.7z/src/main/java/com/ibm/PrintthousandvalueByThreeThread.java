package com.ibm;

public class PrintthousandvalueByThreeThread {

	public static void main(String[] args) {
		int n=4;
		Object [] lock=new Object[n];
		for(int i=0;i<4;i++)
		{
			lock[i]=new Object();
		}
		for(int i=0;i<4;i++)
		{
			new ThousandData("Thread:"+(i+1),lock[i],lock[(i+1)%n]).start();
		}
		

	}

}
class ThousandData extends Thread
{
	String ThreadName;
	Object crrlock;
	Object nexlock;
	static int counter=0;
	ThousandData(String ThreadName,Object crrlock,Object nexlock)
	{
		this.ThreadName=ThreadName;
		this.crrlock=crrlock;
		this.nexlock=nexlock;
	}
	public void print(String ThreadName)
	{
		for(int i=0;i<4;i++)
		{
			System.out.println(ThreadName+"is printing"+(i+1));
		}
	}
	public void run()
	{
		while(counter<10)
		{
			synchronized(crrlock)
			{
				synchronized(nexlock)
				{
					nexlock.notify();
					counter++;
					print(ThreadName);
				}
				try {
					crrlock.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
}
