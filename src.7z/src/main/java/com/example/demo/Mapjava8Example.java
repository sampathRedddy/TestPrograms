package com.example.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Mapjava8Example {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
        map.put("1", "Jan");
        map.put("2", "Feb");
        map.put("3", "Mar");
        map.put("4", "Apr");
        map.put("5", "May");
        map.put("6", "Jun");

        // Standard classic way, recommend!
        System.out.println("\nExample 1...");
        for (Map.Entry<String, String> entry : map.entrySet()) {
            System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
        }

        // Java 8, forEach and Lambda. recommend!
        System.out.println("\nExample 2...");
        map.forEach((k, v) -> System.out.println("Key : " + k + " Value : " + v));

        System.out.println("\nExample 3...");
        
        map.entrySet().stream()
        .forEach( x -> System.out.println("Key : " + x.getKey() + " Value : " + x.getValue()));
        
        map.entrySet().stream()
        .filter(x -> "Jan".equals(x.getValue()))
        .forEach( x -> System.out.println("Key : " + x.getKey() + " Value : " + x.getValue()));
        
        
        
        
        
        ArrayList<String> al=new ArrayList<String>();
        al.add("sampath");
        al.add("pav");
        al.add("sampath");
        al.add("pav");
        
        Set<String> uniqueSet = new HashSet<String>(al);
        for(String temp : uniqueSet) {
        System.out.println(temp+"=============="+Collections.frequency(al, temp));
        }
        al.forEach(a->
        {
        if(a.equals("pav")) {
        System.out.println(a);
        }});
        
        al.stream().filter(a-> "sampath".equals(a)).forEach(a ->System.out.println(a));
		/*
		 * al.forEach(a -> { "pav".equals(a); System.out.println(a); });
		 */
        
        
  List<String> list=   map.keySet().stream().collect(Collectors.toList());
        System.out.println(list);
        
        List<String> listValues=   map.values().stream().collect(Collectors.toList());
        System.out.println(listValues);
	}

}
