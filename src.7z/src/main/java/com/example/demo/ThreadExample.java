package com.example.demo;

public class ThreadExample extends Thread {

	public void run()
	{
		System.out.println("run method ::::");
	}
	public static void main(String[] args) {
		
		ThreadExample obj=new ThreadExample();
		obj.run();
		obj.start();
		
		String s1=new String("sampath");
		String s2=new String(s1);
		
		System.out.println(s1.equals(s2));
		System.out.println(s1==s2);
		
		System.out.println("s1 hashcode :::::"+s1.hashCode());
		System.out.println("s2 hashcode :::::"+s2.hashCode());
		
		
		String s3=new String("ram");
		String s4="ram";
		
		System.out.println(s3.equals(s4));
		System.out.println(s3==s4);
		
		System.out.println("s3 hashcode :::::"+s3.hashCode());
		System.out.println("s4 hashcode :::::"+s4.hashCode());
	}

}
