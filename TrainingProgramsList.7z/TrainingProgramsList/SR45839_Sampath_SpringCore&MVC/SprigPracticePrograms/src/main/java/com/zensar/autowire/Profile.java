package com.zensar.autowire;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Profile {
	private String name;

	@Autowired
	private Student student;
	@Autowired
	
	@Qualifier("person1")
	private Person personProperty;
	
	

	
	public void display()
	{	
		System.out.println("display method of profile bean ::::::::::::::");
		student.getStudent();
		System.out.println(" :::::::::::::::::::::;;"+personProperty.getPersonProperty());
		personProperty.getPerson();
	}

	

	

}
