package com.example.demo;
import java.util.*;  
import java.io.*;  
class Student implements Comparable<Student>{  
int rollno;  
String name;  
int age;  
Student(int rollno,String name,int age){  
this.rollno=rollno;  
this.name=name;  
this.age=age;  
}  



public int getRollno() {
	return rollno;
}



public void setRollno(int rollno) {
	this.rollno = rollno;
}



public String getName() {
	return name;
}


 
public void setName(String name) {
	this.name = name;
}



public int getAge() {
	return age;
}



public void setAge(int age) {
	this.age = age;
}


public int compareTo(Student st){  
if(age==st.age)  
return 0;  
else if(age>st.age)  
return 1;  
else  
return -1;  
}  
}  

class StudentName implements Comparator<Student>
{

	@Override
	public int compare(Student st1, Student st2) {
		
		return st1.name.compareTo(st2.name);
	}
	}

class StudentAge implements Comparator<Student>
{

	@Override
	public int compare(Student st1, Student st2) {
		
		if(st1.age==st2.age)  
			return 0;  
			else if(st1.age>st2.age)  
			return 1;  
			else  
			return -1; 
	}
	}

//Creating a test class to sort the elements  
public class ComarableInterface{  
public static void main(String args[]){  
ArrayList<Student> al=new ArrayList<Student>();  
al.add(new Student(101,"Vijay",23));  
al.add(new Student(106,"Ajay",27));  
al.add(new Student(105,"Jai",21));  


//al.sort((st1)->age-st1.age);
//Comparable<Student> ageComparable = ((st)->age-st.age);
//al.sort(ageComparable);
  
Collections.sort(al);  
//Collections.sort(st- age>st.age>)
for(Student st:al)
{  
System.out.println(st.rollno+" "+st.name+" "+st.age);  
}  
Collections.sort(al,new StudentName());
for(Student st:al)
{  
System.out.println(st.rollno+" "+st.name+" "+st.age);  
}  

al.sort((st1,st2)->st1.name.compareTo(st2.name));
al.sort((st1,st2)-> st1.age-st2.age);



}  
}  