package com.zensar.spring;

import javax.validation.Valid;

import org.hibernate.validator.constraints.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ParamController {
@Autowired
	private ModelFile modelfile;
	
	/*@RequestMapping(value = "/login" , method= RequestMethod.GET)
	@ResponseBody
	public String getParam(@Valid @ModelAttribute String name, @ModelAttribute String password,BindingResult result, Model model)
	{
		System.out.println("========="+name+"========"+password);
		
		
		String resultsData = modelfile.getDisplay(name, password);
         model.addAttribute("resultsPage",resultsData);
         
		
		return "resultsPage";
		
		
		//return name + "======"+ password;
		
	}*/
	
	
	@RequestMapping(value = "/login" , method= RequestMethod.GET)
	@ResponseBody
	public String getParam(@Valid @Email @ModelAttribute String name, @ModelAttribute String password,BindingResult result,Model model)
	{
		System.out.println("========="+name+"========"+password);
		
		
		
         
		
		return "LoginPage";
		
		
		//return name + "======"+ password;
		
	}
	
	@RequestMapping(value = "/loginPage" , method= RequestMethod.GET)
	//@ResponseBody
	public String display1(Model model)
	{
		//System.out.println("input stging ::::::::::"+name1);
		
		model.addAttribute("loginpage");
		
		return "LoginPage";
	}
}


