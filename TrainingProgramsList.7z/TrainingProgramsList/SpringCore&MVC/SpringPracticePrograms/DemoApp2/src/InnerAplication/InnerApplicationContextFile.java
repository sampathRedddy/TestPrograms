package InnerAplication;
	import org.springframework.context.ApplicationContext;
	import org.springframework.context.support.ClassPathXmlApplicationContext;

	public class InnerApplicationContextFile {

		public static void main(String arg[])
		{		
			
			ApplicationContext context = new ClassPathXmlApplicationContext("beanScopeConfig.xml");
			InnerBeanFile.InnerBean ib=(InnerBeanFile.InnerBean) context.getBean("bean");
		    ib.display();
		  
		    
		    InnerBeanFile outer= (InnerBeanFile) context.getBean("outerBean");
		    outer.message();
		}
	}

