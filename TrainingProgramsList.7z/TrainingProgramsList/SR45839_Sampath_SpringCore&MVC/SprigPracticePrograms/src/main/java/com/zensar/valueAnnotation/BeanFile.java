package com.zensar.valueAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class BeanFile {

	private String name;
	private String name1;

	
@Autowired
	public void setName(@Value("${zensar.user}")String name) {
		this.name = name;
		
	}

@Autowired
public void setName1(@Value("${zensar.password}")String name1) {
	this.name1 = name1;
}

public void display()
{
	System.out.println("bean file display method :::::::::::::"+name+"::::::::::::::"+name1);
	
}
	
}
