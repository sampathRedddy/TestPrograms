package com.zensar.autowire;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FirstApp {

	public static void main(String arg[])

	{
		/*
		 * ApplicationContext context=new
		 * ClassPathXmlApplicationContext("beansConfig.xml"); Profile
		 * beanObject=context.getBean("profile",Profile.class);
		 * 
		 * System.out.println("First Appllication :::::::::::::"+beanObject);
		 * beanObject.display();
		 */
	
	ApplicationContext context = new AnnotationConfigApplicationContext(BeanFile.class);
	Profile p=context.getBean("profile",Profile.class);
	p.display();
	
	}
}
