import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopeApplication {

	public static void main(String arg[])
	{
		//System.out.println("hello world:::::::");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beanScopeConfig.xml");
	    Student std=context.getBean("student",Student.class);
	    std.setStudentName("Sampath");
	    System.out.println("Student Name :::::::::::"+std.getStudentName());
	    
	   
	    Student std1=context.getBean("student",Student.class);
	   // std1.setStudentName("Ram");
	    
	    System.out.println("Student Name :::::::::::"+std1.getStudentName());
	   
	}
}
