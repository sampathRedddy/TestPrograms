package com.zensar.controller;

import javax.validation.Valid;

import org.hibernate.validator.constraints.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zensar.component.calculatorInterface;
import com.zensar.login.LoginBean;



@Controller
public class TestController {
 
	@Autowired
	TestModel testModel;
	
	/*
	 * @Autowired
	 * 
	 * @Qualifier(value = "calculatorImp1") calculatorInterface calInterface;
	 * 
	 * @Autowired
	 * 
	 * @Qualifier(value = "calculatorImp2") calculatorInterface calInterface1;
	 */
	
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	//@ResponseBody
	public String display(Model model)
	
	{
		model.addAttribute("firstApp", "This is first Application");
		
		return "first";
	}
	
	@RequestMapping(value = "/home1/{cal1}/{cal2}", method = RequestMethod.GET)
	//@ResponseBody
	public String display1(@PathVariable("cal1") int cal1 ,@PathVariable("cal2") int cal2,Model model)
	
	{
		System.out.println("name :::::::::"+cal1+"========="+cal2);
		
		int results = testModel.calculate(cal1, cal2);
		
     	//int results = calInterface.add(cal1, cal2);
	
		model.addAttribute("firstApp", results);
		
		return "first";
	}
	
	@RequestMapping(value = "/login" , method= RequestMethod.GET)
	@ResponseBody
	public String getParam(@ModelAttribute String name, @ModelAttribute String password,BindingResult result)
	{
		System.out.println("========="+name+"========"+password);
		
		
		
         
		
		return "LoginPage";
		
		
		//return name + "======"+ password;
		
	}
	
	 @RequestMapping(value = "/loginPage", method = RequestMethod.GET)
	  //@ResponseBody
	  public String init(Model model) {
	    model.addAttribute("msg", "Please Enter Your Login Details");
	    return "Login";
	  }
	 @RequestMapping(method = RequestMethod.POST)
	  public String submit(Model model, @ModelAttribute("loginBean") LoginBean loginBean) {
	    if (loginBean != null && loginBean.getUserName() != null & loginBean.getPassword() != null) {
	      if (loginBean.getUserName().equals("chandra") && loginBean.getPassword().equals("chandra123")) {
	        model.addAttribute("msg", loginBean.getUserName());
	        return "success";
	      } else {
	        model.addAttribute("error", "Invalid Details");
	        return "Login";
	      }
	    } else {
	      model.addAttribute("error", "Please enter Details");
	      return "Login";
	    }
	  }
}
