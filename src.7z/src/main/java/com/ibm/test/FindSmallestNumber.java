package com.ibm.test;

public class FindSmallestNumber {

	public static void main(String[] args) {
		
		int a[]= {4,3,5,2,7,9,8};
		int smallestNo=a[0];
		int snumber = 0;
		
		for(int i=0;i<a.length;i++)
		{
			if(smallestNo>a[i])
			{
				snumber=a[i];
				//break;	
			}
		}
System.out.println("smallest number is :::::::::;"+snumber);
	}

}
