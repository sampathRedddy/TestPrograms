package com.ibm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class ManagerEmployeeInformation {

	
	public static void main(String[] args) {
		List<Employee> list1=new ArrayList<Employee>();
		list1.add(new Employee(1,"rahul","chaturvedi",10000,"engineer","male","UP","single"));
		list1.add(new Employee(2,"balbir","singh",20000,"doc","male","MP","married"));
		list1.add(new Employee(3,"rohit","kumar",80000,"engineer","male","bihar","single"));
		list1.add(new Employee(4,"ram","chuhan",60000,"teacher","male","Delhi","married"));
		list1.add(new Employee(5,"ritu","gupta",40000,"doc","female","UP","single"));
		list1.add(new Employee(6,"riya","chaturvedi",50000,"engineer","female","Karnatka","single"));
		list1.add(new Employee(7,"rah","chaturvedi",90000,"doc","male","punjab","married"));
		Collections.sort(list1, new Employee.sortbasedonsalary());
		Collections.sort(list1, new Employee.sortbasedonname());
		
		//System.out.println(list1);
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the criteria");
		String s1=sc.next();
		if(s1.equalsIgnoreCase("male"))
		{
			MaleInformation m1=new MaleInformation();
			m1.meetinformation(list1);
		}
		if(s1.equalsIgnoreCase("female"))
		{
			FemaleInformation m1=new FemaleInformation();
			m1.meetinformation(list1);
		}
		if(s1.equalsIgnoreCase("malesingle")||s1.equalsIgnoreCase("singlemale"))
		{
			Singlemale m2=new Singlemale();
			m2.meetinformation(list1);
			
		}
		
			
		if(s1.equalsIgnoreCase("serialinfo"))
		{
			Serialnoinfo m2=new Serialnoinfo();
			m2.meetinformation(list1);
			
		}
		
		

	}

}
interface Information
{
	public void meetinformation(List<Employee> list2);
}
class MaleInformation implements Information
{

	@Override
	public void meetinformation(List<Employee> list2) {
		ArrayList<Employee> list3=new ArrayList<Employee>();
		for(Employee e:list2 )
		{
			if(e.getGender().equalsIgnoreCase("male"))
			{
				list3.add(e);
			}
		}
		System.out.println(list3);
		
	}
	
}
class FemaleInformation implements Information
{

	@Override
	public void meetinformation(List<Employee> list2) {
		ArrayList<Employee> list3=new ArrayList<Employee>();
		for(Employee e:list2 )
		{
			if(e.getGender().equalsIgnoreCase("female"))
			{
				list3.add(e);
			}
		}
		System.out.println(list3);
		
	}
}
	class Singlemale implements Information
	{

		@Override
		public void meetinformation(List<Employee> list2) {
			ArrayList<Employee> list3=new ArrayList<Employee>();
			
			for(Employee e:list2 )
			{
				if(e.getGender().equalsIgnoreCase("male")&&e.getMstatus().equalsIgnoreCase("single"))
				{
					list3.add(e);
				}
			}
			System.out.println(list3);
			
		}
	
}
	class Serialnoinfo implements Information
	{

		@Override
		public void meetinformation(List<Employee> list2) {
			System.out.println("Enter the serialno");
			Scanner sc=new Scanner(System.in);
			int sn=Integer.parseInt(sc.next());
			ArrayList<Employee> list3=new ArrayList<Employee>();
			for(Employee e:list2 )
			{
				if(sn==e.serialNo)
				{
					list3.add(e);
				}
			}
			System.out.println(list3);
			
			
			
		}
		
	}



class Employee
{
	int serialNo;
	String Firstname;
	String Lastname;
	int salary;
	String profession;
	String gender;
	String state;
	String Mstatus;
	
	Employee(int serialNo,String Firstname,String Lastname,int salary,String profession,String gender,String state,String Mstatus)
	{
		this.serialNo=serialNo;
		this.Firstname=Firstname;
		this.Lastname=Lastname;
		this.salary=salary;
		this.profession=profession;
		this.gender=gender;
		this.state=state;
		this.Mstatus=Mstatus;
	}
	public String toString()
	{
		return "("+serialNo+","+Firstname+","+Lastname+","+salary+","+profession+","+gender+","+ state+","+Mstatus+")";
		
	}
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMstatus() {
		return Mstatus;
	}
	public void setMstatus(String mstatus) {
		Mstatus = mstatus;
	}
	static class sortbasedonsalary implements Comparator
	{

		@Override
		public int compare(Object arg0, Object arg1) {
			Employee emp1=(Employee)arg0;
			Employee emp2=(Employee) arg1;
			return emp1.getSalary()-emp2.getSalary();
		
		
	}
	}
		static class sortbasedonname implements Comparator
		{

			@Override
			public int compare(Object arg0, Object arg1) {
				Employee emp1=(Employee)arg0;
				Employee emp2=(Employee)arg1;
				return emp1.getFirstname().compareTo(emp2.getFirstname());
				
			}
			
		}
	
}

