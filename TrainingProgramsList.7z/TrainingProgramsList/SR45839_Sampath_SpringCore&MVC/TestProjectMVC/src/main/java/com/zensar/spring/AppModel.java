package com.zensar.spring;

public class AppModel {

	private String modelName;

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	
	public void getModel()
	{
		
		System.out.println("GetModel Method invokedd;;;;;;;;;;;;;;;");
	}
	
	
}
