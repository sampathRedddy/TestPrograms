package com.zensar.controller;

import org.springframework.stereotype.Component;

@Component
public class TestModel {

	public int calculate(int c1,int c2)
	{
		
		int c3=c1+c2;
	return c3;
	
	}
}
