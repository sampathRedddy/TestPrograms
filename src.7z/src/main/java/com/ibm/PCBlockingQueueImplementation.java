package com.ibm;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class PCBlockingQueueImplementation {

	public static void main(String[] args) {
		BlockingQueue<Integer> q=new ArrayBlockingQueue<Integer>(1);
		Producer p1=new Producer(q);
		Consumer c1=new Consumer(q);
		p1.start();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c1.start();
		
	}

} 
class Producer extends Thread
{
	BlockingQueue<Integer> q;
	Producer(BlockingQueue<Integer> queue)
	{
		this.q=queue;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			try {
				q.put(i);
				System.out.println("Producer producing :" +i);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
	}
}
class Consumer extends Thread
{
	BlockingQueue<Integer> q;
	Consumer(BlockingQueue<Integer> queue)
	{
		this.q=queue;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			try {
				System.out.println("Consumer is consuming :" +q.take());
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}