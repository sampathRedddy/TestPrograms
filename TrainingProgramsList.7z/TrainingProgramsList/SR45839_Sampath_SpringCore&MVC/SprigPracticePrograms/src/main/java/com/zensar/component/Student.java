package com.zensar.component;

import org.springframework.stereotype.Component;

@Component
public class Student {

	public void getStudent()
	{
		System.out.println("getStudent Method is calling ::::::::::::::;");
	}
}
