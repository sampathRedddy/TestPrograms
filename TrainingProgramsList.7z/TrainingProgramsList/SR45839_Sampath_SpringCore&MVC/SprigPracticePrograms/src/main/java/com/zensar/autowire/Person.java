package com.zensar.autowire;

public class Person {

	/*
	 * private int age;
	 * 
	 * public int getAge() { System.out.println("age ::::::::::;"+age); return age;
	 * }
	 * 
	 * public void setAge(int age) { this.age = age;
	 * 
	 * }
	 */
	private String personProperty;
	
	public String getPersonProperty() {
		return personProperty;
	}

	public void setPersonProperty(String personProperty) {
		this.personProperty = personProperty;
	}

	public void getPerson()
	{
		System.out.println("getPerson Method is calling ::::::::::::::;");
	}
	
}
