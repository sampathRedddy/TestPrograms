package com.example.demo;

import org.springframework.data.repository.CrudRepository;

public interface TopicsRepository extends CrudRepository<Topics, String> {

}
