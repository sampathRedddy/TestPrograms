package com.example.demo;

 class A
{
	 private void m1()
	 {
		 System.out.println("m1 method of A class");
	 }
	}

 class B extends A
{
	 public void m1()
	 {
		 System.out.println("m1 method of B class");
	 }
	}
 class C extends B
{
	 public void m2()
	 {
		 System.out.println("m2 method of C class");
	 }
	}

 
public class InheritenceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	C objC=new C();
	objC.m1();

	Double d1=new Double("12.12");
	Double d2=12.12;
	Double d3=d2;
	System.out.println("=================="+(d3==d2));
	
	System.out.println(d2.equals(d3));
	
	String s1=new String("sampath");
	String s2=new String("sampath");
	String s3="sampath";
	System.out.println("===="+(s2==s1));
	System.out.println("===="+(s2==s3));
	System.out.println("equlsl si::::::"+s1.equals(s2));
	System.out.println("equlsl si::::::"+s1.equals(s3));
	}

}
