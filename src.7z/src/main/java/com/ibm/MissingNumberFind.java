package com.ibm;

import java.util.Scanner;

public class MissingNumberFind {

	
	public static void main(String[] args) {
		int [] a1={3,5,6,1,8,10,2,7,4,11,12,13,14,18,19,20,16,15,17};
		int sum1=0;
		int sum2=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("total no");
		String s2=sc.next();
		int n=Integer.parseInt(s2);
		sum1=n*(n+1)/2;
		System.out.println(sum1);
		System.out.println("....");
		for(int i=0;i<a1.length;i++)
		{
			sum2=sum2+a1[i];
		}
		System.out.println("the missing number in array is : " +(sum1-sum2));
		

	}

}
