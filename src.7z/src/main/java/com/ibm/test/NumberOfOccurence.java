package com.ibm.test;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NumberOfOccurence {

	public static void main(String[] args) {
		String str = "helloslkhellodjladfjhello";
		String findStr = "hello";
		int lastIndex = 0;
		int count = 0;

		while(lastIndex != -1){

		    lastIndex = str.indexOf(findStr,lastIndex);
           System.out.println("lastIndex is;::::"+lastIndex);
		    if(lastIndex != -1){
		        count ++;
		        lastIndex += findStr.length();
		       System.out.println("result is;::::"+lastIndex);
		    }
		}
		System.out.println(count);
		
		System.out.println("====="+Arrays.asList(str.split(findStr, -1)));
		//Arrays.asList(str.split(findStr, -1));
		
		System.out.println(str.split(findStr, -1).length-1);
		//System.out.println(StringUtils.countMatches(str, findStr));
		
		Pattern p = Pattern.compile("hello");
		Matcher m = p.matcher(str);
		int count1 = 0;
		while (m.find()){
		    count1 +=1;
		}
		System.out.println("pattern is ::::::::;"+count1); 
		
		
		 String string = "Spring is beautiful but so is winter";
	      String word = "is";
	      String temp[] = string.split(" ");
	      int count2 = 0;
	      for (int i = 0; i < temp.length; i++) {
	         if (word.equals(temp[i])) 
	            count2++;
	      }
	      System.out.println("The string is: " + string);
	      System.out.println("The word " + word + " occurs " + count2 + " times in the above string");
	      
	      
	      
	}

}
