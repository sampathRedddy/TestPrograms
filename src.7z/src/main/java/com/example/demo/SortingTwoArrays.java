package com.example.demo;

public class SortingTwoArrays {

	
	public static void main(String[] args)
	{
		
		/*int a[]= {2,6,3,8,12,5};
		int b[]= {9,4,6,1};
		int c[]=new int[a.length+b.length];
        int j=0;
		for(int i=0;i<b.length;i++)
		{
			while(b[i]>a[j])
			{
				c[j]=a[j];
				j++;
			}
			if(b[i]==a[j])
			{
				c[j]=b[i];
				c[j+1]=a[j];
			}
			
			else {
				c[j]=b[i];
				j++;
			}
			for(int k=0;k<c.length;k++)
			{
				System.out.println(c[k]);
			}
			
		}*/
		
		
		
		int a [] = {3,5,7,9,12,14, 15};
	    int b [] = {6 ,7, 10};
	    int j = 0;

	    //output array should be 3,5,6,7,7,9,10,12,14,15

	    int c [] = new int[a.length+b.length];//10 values

	    for (int i = 0;i<b.length;i++){
	        if(b[i]>a[j]){
	            c[j] = a[j] ;
	            j++;    
	         }

	        if(b[i] == a[j]){
	            c[j] = b[i];
	            c[j+1] = a[j];
	        }
	        else {
	        c[j] = b[i];
	        j++;
	        }
	    }

	    for(int i = 0;i<c.length;i++)
	        System.out.println(c[i]);
	    }
	
	
	}


