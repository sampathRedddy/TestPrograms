package com.ibm;

import java.util.Scanner;

public class MissingTwoCharecter {

	
	public static void main(String[] args) {
		char [] ac={'b','c','a','e','h','k','l','g','i','j','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		int asciioffirstcharecter =97;
		int asciioflastcharecter=122;
		int sumas1=0;
		int sumas2=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter total no of charecter");
		int n=sc.nextInt();
		sumas1=n/2*(asciioffirstcharecter+asciioflastcharecter);
		for(int i=0;i<ac.length;i++)
		{
			 sumas2=sumas2+(int)ac[i];
		}
		int sumas3=sumas1-sumas2;
		char missing=(char)sumas3;
		System.out.println(missing);

	}


}
