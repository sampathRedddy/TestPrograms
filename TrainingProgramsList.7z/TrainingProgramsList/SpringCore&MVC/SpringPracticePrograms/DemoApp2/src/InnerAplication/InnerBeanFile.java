package InnerAplication;

public class InnerBeanFile {

	public void message()
	{
		System.out.println("Message method ===========");
	}
	
	public static class InnerBean{
		
		public InnerBean()
		{
			System.out.println("Default constructor");
		}
		 
		 public void display()
		 {
			 
			 System.out.println("display method ==========");
		 }
		 
		 
	}
}
