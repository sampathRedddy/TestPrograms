package com.zensar.spring;

import org.springframework.stereotype.Component;

@Component
public class CalculatorFile implements CalculatorInterface{

	@Override
	public int add(int a, int b) {
		
	return a+b;	
	}

	@Override
	public int add(int a, int b, int c) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
