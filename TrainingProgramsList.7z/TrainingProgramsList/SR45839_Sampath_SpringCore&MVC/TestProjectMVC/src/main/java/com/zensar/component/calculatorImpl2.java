package com.zensar.component;

import org.springframework.stereotype.Component;

@Component
public class calculatorImpl2 implements calculatorInterface{

	
	public int add(int cal1, int cal2) {
		
	
		return 0;
	}

	
	/*
	 * public int add(int cal1, int cal2, int cal3) {
	 * 
	 * return 0; }
	 */
	
}
