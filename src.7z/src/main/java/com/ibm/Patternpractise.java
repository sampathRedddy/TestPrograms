package com.ibm;

public class Patternpractise {

	
	public static void main(String[] args) {
		String s1="SAA*AA*ASAA*AAS*ASA*AA*AA*SAS*SSAA";
		for(String s2:s1.split("[*]"))
		{
		for(String s3:s2.split("[S][A]+"))
		{
			System.out.println(s3);
			
		}
		}

	}

}
