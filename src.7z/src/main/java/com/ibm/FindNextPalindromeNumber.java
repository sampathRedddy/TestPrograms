package com.ibm;

import java.util.Scanner;

public class FindNextPalindromeNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no and palidrome should be first next that no");
		int i=sc.nextInt();
		int k=i+1;
		while(k>i)
		{
			if(ispalindrome(k))
			{
				System.out.println("the palindrome no is :" +k);
				break;
			}
			else
			{
				k++;
			}
		}
	}
	public static boolean ispalindrome(int k)
	{
		int num=k;
		int sum=0;
		while(k>0)
		{
			int n=k%10;
		    sum=sum*10+(n);
		    k=k/10;
		}
		if(num==sum)
		{
			return true;
		}
		return false;
	}

}
