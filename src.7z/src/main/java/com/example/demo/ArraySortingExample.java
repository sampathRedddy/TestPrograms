package com.example.demo;

import java.util.HashMap;
import java.util.Map;

public class ArraySortingExample {

	public static void main(String arg[])
	{
		int a[]= {1,3,8,5,6,3,2,0};
		int temp;
		for(int i=0;i<a.length;i++)
		{
		 for(int j=i+1;j<a.length;j++)
		 {
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		 }
		}
		System.out.println("arry sort is ::::::::"+a);
		for(int k=0;k<a.length;k++)
		{
			System.out.println("soring "+a[k]);
		}
		
		
		HashMap<Integer,String> h=new HashMap<Integer,String>();
		h.put(1, "samp");
		h.put(2,"pav");
		h.put(null,"samppaht");
		h.put(null,"dsfdsf");
		
	System.out.println(h.get(null));
		
	for(Map.Entry<Integer,String> mp : h.entrySet())
	{
		System.out.println(mp.getKey()+":::::::::::"+mp.getValue());
		
	}
		
	h.forEach((k,v)-> System.out.println(k+"----"+v));
	
	String str="sampath";
	String str1="pav";
	
	
	
	
		
	}
}
