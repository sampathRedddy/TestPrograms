package com.zensar.component;



public interface calculatorInterface {
    //@Bean(name="interface1")
	 int add(int cal1,int cal2);
   // @Bean(name="interface2")
	// int add(int cal1,int cal2,int cal3);
}
