package com.ibm.test;

public class SecondHighestValue {

	public static void main(String[] args) {
		
		int a[]= {4,3,5,2,7,9,8};
		int highValue=a[0];
		int secondHighValue=a[0];
	
	for(int i=0;i<a.length;i++)
	{
		
		if(a[i]>highValue)
		{
			secondHighValue=highValue;
			highValue=a[i];
			
		}
		else if(a[i]>secondHighValue){
			secondHighValue=a[i];
		}
	}
	System.out.println("second highest valeus ::::::"+secondHighValue);
	}

}
