
public class InitClass {

	private String ConstructName;
	
	InitClass()
	{
		
	}
	InitClass(String name){
		System.out.println("InitClass constructor");
	}
	
	
	
	
	public void initMethodSingle()
	{
		System.out.println("initMethodSingle");
	}
	
	public void initMethodProto()
	{
		System.out.println("initMethodProto");
	}
}
