package com.ibm;
class T
{
	int value=1;
	public synchronized void set()
	{
		if(value%2==0)
		{
			System.out.println("Even value is :" +value);
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		value++;
		notify();
	}
	public synchronized void getvalue()
	{
		if(value%2!=0)
		{
			System.out.println("Odd value is :" +value);
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		value++;
		notify();
	}
}
class Producer1 extends Thread
{
	T t;
	Producer1(T t)
	{
		this.t=t;
		
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			t.set();
		}
	}
}
class Consumer1 extends Thread
{
	T t;
	Consumer1(T t)
	{
		this.t=t;
		
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			t.getvalue();
		}
	}
}
public class PCEvenOdd {
	public static void main(String[] args) { 
		T t=new T();
		Producer1 p1=new Producer1(t);
		Consumer1 c1=new Consumer1(t);
		p1.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c1.start();
	}

}
