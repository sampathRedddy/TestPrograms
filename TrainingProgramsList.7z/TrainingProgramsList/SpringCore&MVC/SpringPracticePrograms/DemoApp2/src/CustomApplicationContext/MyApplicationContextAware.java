package CustomApplicationContext;
import java.util.Arrays;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.context.event.ApplicationContextEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ResourceLoader;

public class MyApplicationContextAware implements ApplicationContextAware,BeanClassLoaderAware,BeanNameAware,ResourceLoaderAware {


	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		
		System.out.println("ApplicationContext method"+getClass());
		System.out.println("ApplicationContext BeanDefinitionNames method"+Arrays.toString(applicationContext.getBeanDefinitionNames()));
	}

	@Override
	public void setBeanClassLoader(ClassLoader classLoader) {
		
		System.out.println("BeanClassLoader method"+getClass());
	}

	@Override
	public void setBeanName(String name) {
		
		System.out.println("BeanName method"+name);
	}

	@Override
	public void setResourceLoader(ResourceLoader resourceLoader) {
		
		System.out.println("ResourceLoader method"+getClass());	
	}
}
