package com.example.demo;

public class exceptionFile {
	public void display()
	{
      try {
		for(int i=0;i<=5;i++)
		{
			System.out.println("values is::::::"+i);
			//if(i/4==1)
			//{
				System.exit(-1);
			//}
		}
		}
		catch(Exception e){
			System.out.println("catch block ::::::::;;");
		}
      finally{
    	 System.out.println("finally block:::::::::;"); 
      }
	}

	public static void main(String arg[])
	{
		exceptionFile obj=new exceptionFile();
		obj.display();
	}
}
