INSERT INTO users VALUES (1, 'ram', 'ram@gmail.com');
INSERT INTO users VALUES (2, 'shyam', 'shyam@yahoo.com');
INSERT INTO users VALUES (3, 'sumit', 'sumit@gmail.com');