package com.zensar.component;

import org.springframework.stereotype.Component;

@Component
public class Person {

	/*
	 * private int age;
	 * 
	 * public int getAge() { System.out.println("age ::::::::::;"+age); return age;
	 * }
	 * 
	 * public void setAge(int age) { this.age = age;
	 * 
	 * }
	 */
	public void getPerson()
	{
		System.out.println("getPerson Method is calling ::::::::::::::;");
	}
	
}
