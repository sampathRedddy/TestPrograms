package com.zensar.rolebasedoauth2.model;

public enum RoleType {

    ADMIN,USER_CREATE,USER_UPDATE,USER
}
