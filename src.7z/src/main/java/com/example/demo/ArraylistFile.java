package com.example.demo;

import java.util.ArrayList;
import java.util.List;

public class ArraylistFile {

	public static void main(String arg[])
	{
		ArrayList<String> al=new ArrayList<String>();
		al.add("sampath");
		al.add("pav reddy");
		al.add("chintu");
		
		/*
		 * for(int i=0;i<al.size();i++) { //al.add("love");
		 * //System.out.println("arylist is ::::::::"+al.get(i));
		 * if(al.contains("pav"));{ al.remove("pav"); }
		 * 
		 * }
		 */
		
		String str=new String("sampath");
	
		for(String s : al)
		{
			if(s.contains("pav"));{
	               al.remove(s);
	           }
			System.out.println(s);
		}
//		 List<String> listOfBooks = new ArrayList<>();  
//	       listOfBooks.add("Programming Pearls");
//	       listOfBooks.add("Clean Code");
//	       listOfBooks.add("Effective Java");
//	       listOfBooks.add("Code Complete");
//	       
//	       // Using forEach loop to iterate and removing 
//	       // element during iteration will throw 
//	       // ConcurrentModificationException in Java
//	       for(String book: listOfBooks){
//	           if(book.contains("Code"));{
//	               listOfBooks.remove(book);
//	           }
//	       }
//	   }

	}	
	
}
