//ADD two large number which we can not store in int
package com.ibm;

import java.util.ArrayList;
import java.util.Collections;

public class AddTwoLargeNumber {

	public static void main(String[] args) { 
		String s1="238679345675";
		String s2="145678238567";
		add(s1,s2);
		

	}
	
	public static void add(String s1,String s2)
	{
		Integer carry=0;
		int i=s1.length()-1;
		int j=s2.length()-1;
		
		
		ArrayList<String> list1=new ArrayList<String>();
		while(true)
		{
			Integer first=Integer.parseInt(Character.toString(s1.charAt(i)));
			Integer second =Integer.parseInt(Character.toString(s2.charAt(j)));
			Integer sum=first+second+carry;
			
			if(first+second+carry>=10)
			{
				carry=1;
				sum=sum%10;
			}
			else
			{
				carry=0;
			}
			list1.add(sum.toString());
			i--;
			j--;
			if(i<0)
			{
				list1.add(carry.toString());
				break;
			}
			
		}
		Collections.reverse(list1);
		for(String s3:list1)
		{
			System.out.print(s3);
		}
	}

}
