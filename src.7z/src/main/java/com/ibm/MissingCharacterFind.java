package com.ibm;

import java.util.Scanner;

public class MissingCharacterFind {
	
	public static void main(String[] args) {
		char [] ac={'b','c','a','d','e','h','k','l','g','i','j','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		int asciioffirstcharecter =97;
		int asciioflastcharecter=122;
		int sumas1=0;
		int sumas2=0;
		System.out.println("a ascii code is ::::::;"+ac.hashCode());
		System.out.println("===="+ac[0]);
		//Scanner sc=new Scanner(System.in);
		//System.out.println("enter total no of charecter");
		//int n=sc.nextInt();
		int n=26;
		sumas1=n/2*(asciioffirstcharecter+asciioflastcharecter);
		System.out.println("sumas1 is :::::::::::"+sumas1);
		for(int i=0;i<ac.length;i++)
		{
			 sumas2=sumas2+(int)ac[i];
		}
		int sumas3=sumas1-sumas2;
		char missing=(char)sumas3;
		System.out.println("the missing charecter is : " +missing);
	}
	
	

}
