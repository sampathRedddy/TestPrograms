package com.zensar.spring.test;


public interface LogWriter {
	public void write(String text);
}
