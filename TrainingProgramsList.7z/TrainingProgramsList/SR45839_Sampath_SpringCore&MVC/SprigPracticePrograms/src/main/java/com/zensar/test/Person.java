package com.zensar.test;

public class Person {

	private int age;

	public int getAge() {
		System.out.println("age ::::::::::;"+age);
		return age;
	}

	public void setAge(int age) {
		this.age = age;
		
	}
	
	
}
