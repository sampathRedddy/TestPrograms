package com.ibm.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.WeakHashMap;

public class FileReadTest {

	public static void main(String[] args) throws IOException {
		
		 File file = new File("C:\\IBM\\text.txt"); 
		  
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  
		  String st; 
		  while ((st = br.readLine()) != null) {
		    System.out.println(st); 
		  }
		  
		  FileReader fr = 
			      new FileReader("C:\\IBM\\text.txt"); 
		 
		int i;
		while ((i = fr.read()) != -1)
			System.out.print("--" + (char) i);
		System.out.print("--" + (int) i);
		
		
		
		WeakHashMap wh= new WeakHashMap();
		wh.put("sampath", 1);
		wh.put("pavani", 2);
		wh.put(null,3);
		wh.put(null,4);
		
		System.out.println("weakhash map ::::::::::::"+wh.get(null));
		
		
		
		
		  } 

	}


