package com.zensar.rolebasedoauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoleBasedOauth2Application {

	public static void main(String[] args) {
		SpringApplication.run(RoleBasedOauth2Application.class, args);
	}

}

