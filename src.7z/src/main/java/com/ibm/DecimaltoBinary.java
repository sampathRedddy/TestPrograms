package com.ibm;

import java.util.Scanner;

public class DecimaltoBinary {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter the decimal no");
		int s=sc.nextInt();
		int[] a=new int[25];
		int position=0;
		while(s>0)
		{
			int n=s%2;
			a[position]=n;
			position=position+1;
			s=s/2;
			
			
		}
		
		for(int i=a.length-1;i>=0;i--)
		{
			
			System.out.print(a[i]);
			
		}
		
	}

}
