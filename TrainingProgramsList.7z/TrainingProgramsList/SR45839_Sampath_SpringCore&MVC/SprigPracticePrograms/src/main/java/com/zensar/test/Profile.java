package com.zensar.test;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Profile {
	private String name;
	private int age;
	private Set address;
	private List addressList;
	private Map addressMap;
	private Properties props;
	private Student student;
	private Person personProperty;
	
	Profile(int age)
	{
		System.out.println("constructoer age ::::::::::;"+age);
	}

	public Person getPersonProperty() {
		return personProperty;
	}

	public void setPersonProperty(Person personProperty) {
		this.personProperty = personProperty;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Properties getProps() {
		return props;
	}

	public void setProps(Properties props) {
		this.props = props;
	}

	public List getAddressList() {
		return addressList;
	}

	public void setAddressList(List addressList) {
		this.addressList = addressList;
	}

	public Map getAddressMap() {
		return addressMap;
	}

	public void setAddressMap(Map addressMap) {
		this.addressMap = addressMap;
	}

	public Set getAddress() {
		return address;
	}

	public void setAddress(Set address) {
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	public void display()
	{
		System.out.println("profile display method ::::::::::::::");
		student.getStudent();
		personProperty.getAge();
		
		System.out.println("ppersonProperty.getAge() ::::::::::::::"+personProperty.getAge());
	}

	@Override
	public String toString() {
		return "Profile [name=" + name + ", address=" + address + ", addressList=" + addressList + ", addressMap="
				+ addressMap + ",propetes="+props+"]";
	}

	

	

}
