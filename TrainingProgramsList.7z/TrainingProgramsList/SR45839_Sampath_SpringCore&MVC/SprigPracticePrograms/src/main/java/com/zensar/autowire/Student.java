package com.zensar.autowire;

public class Student {

	public void getStudent()
	{
		System.out.println("getStudent Method is calling ::::::::::::::;");
	}
}
