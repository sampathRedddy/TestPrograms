package com.ibm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Extractvalidmobnofromfile {

	public static void main(String[] args) throws IOException {
		File f2=new File("output.txt");
		PrintWriter out=new PrintWriter(f2);
		File f1=new File("input.txt");
		FileReader fr=new FileReader(f1);
		BufferedReader br=new BufferedReader(fr);
		String sb=br.readLine();
		Pattern pn=Pattern.compile("[7-9][0-9]{9}");
		while(sb!=null)
		{
			Matcher m=pn.matcher(sb);
			while(m.find())
			{
				out.println(m.group());
				System.out.println(m.group());
			}
			sb=br.readLine();
		}
		out.flush();

	}
	

}
