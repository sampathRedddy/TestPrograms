package com.zensar.component;

public class Address {
	
	public void getAddress()
	{
		
		System.out.println("getAddress ::::::::::::::");
	}

}
