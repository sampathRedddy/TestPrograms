package com.ibm;

public class ReverseStringWithrecursion {
   static String s1="";
	
	public static void main(String[] args) {
		
		String s2=reversestring("rahulchaturvedi");
		System.out.println(s2);
		
		
	}

	public static String reversestring(String str)
	{
		if(str.length()==1)
		{
			return str;
		}
		else
		{
		
			 s1+= str.charAt(str.length()-1) +reversestring(str.substring(0,str.length()-1));
			
		}
		
		return s1;
		
		
		
		
	}
}

