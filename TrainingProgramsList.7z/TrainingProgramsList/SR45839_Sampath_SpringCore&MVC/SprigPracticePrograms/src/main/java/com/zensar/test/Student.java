package com.zensar.test;

public class Student {

	private String sname;
	private Address addressProperty;
	
	public Address getAddressProperty() {
		return addressProperty;
	}


	public void setAddressProperty(Address addressProperty) {
		this.addressProperty = addressProperty;
	}


	public String getSname() {
		return sname;
	}


	public void setSname(String sname) {
		this.sname = sname;
	}


	public void getStudent()
	
	{
		System.out.println("getStudent method ::::::::::::::");
		addressProperty.getAddress();
	}
}
