package com.zensar.spring;

import org.springframework.stereotype.Component;


public interface CalculatorInterface {

int add(int a,int b);
int add(int a,int b,int c);
}
