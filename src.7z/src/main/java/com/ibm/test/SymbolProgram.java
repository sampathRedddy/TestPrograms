package com.ibm.test;

public class SymbolProgram {

	public static void main(String[] args) {
		int n=5;
		
		for(int i=0;i<n;i++)
		{
			/*
			 * for(int j=i+1;j<n;j++) { System.out.print(" "); }
			 */
			
			
			for (int k = 0; k <= i; k++) {
				System.out.print("* ");
			}
			System.out.println();
		
		}
		
		for(int i=1;i<=n;i++)
		{
			
			 for(int k=n;k>=i;k--)
				{
					System.out.print("* ");
				}
				//System.out.println("===================");
				 System.out.println();
		
		}
	}

}
