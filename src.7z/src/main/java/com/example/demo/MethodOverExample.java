package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

class superClass
{
	 public void display(Object i)
	 {
		 System.out.println("super class method");
	 }
	}
public class MethodOverExample extends superClass{
	 public void display(String s)
	 {
		 System.out.println("sub class method");
		// return "sampath";
	 }
	public static void main(String[] args) {
		
		superClass obj=new MethodOverExample();
        obj.display(null);
        
        
        ArrayList<String> al= new ArrayList<String>();
        al.add("sampath");
        al.add("chint");
        al.add("ram");
       
       al.forEach(list -> System.out.println(list));
       
       Iterator it=al.iterator();
       while(it.hasNext())
       {
    	   System.out.println("iterator is :::::::::::;"+it.next());
       }
        al.forEach(l -> {
        	if(l.contains("ram"))
        	{
        	System.out.println("containsmetod ::::::;;;");
        	}
        });
        
        HashMap<Integer,String> hmap= new HashMap<Integer,String>();
        hmap.put(1, "sampath");
        hmap.put(2, "sampath12");
        hmap.put(3, "sampath123");
        
        hmap.values().forEach(System.out :: println);
        
        Iterator itmap=hmap.entrySet().iterator();
        while(itmap.hasNext())
        {
        	Map.Entry<Integer, String> itmapEntry=(Entry<Integer, String>) itmap.next();
        	System.out.println(itmapEntry.getKey()+"itmapEntry:::"+itmapEntry.getValue());
        }
        
        hmap.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v));   
        
        hmap.forEach((k,v)->{
    		System.out.println("Item : " + k + " Count : " + v);
    		if("sampath".equals(v)){
    			System.out.println("Hello E");
    		}
    	});
        
		/*
		 * String[] str = new String[10]; //Getting the substring
		 * System.out.print("substing is::::::::::::"+str[9]); String str2 =
		 * str[9].substring(2, 5); //Displaying substring
		 * System.out.print("substing is::::::::::::"+str2);
		 */ 
        
        String strr="sampa";
	int length=strr.length()/2;
	if(length%2==0)
	{
		System.out.println(strr.charAt(length)-1);
		System.out.println(strr.charAt(length));
	}else
	{
		System.out.println(strr.charAt(length));
	}
        
     String s=new String();
     
     for(int i=0;i<strr.length();i++) {
    	 char c=strr.charAt(i);
            if(s.indexOf(c)<0)
         {
    s=s+c;	 
     }
     }
     System.out.println("After duplicating the values ::::::"+s);
     
     char c[]=strr.toCharArray();
     for(int i=0;i<strr.length();i++)
     {
    	 for(int j=i+1;j<strr.length();j++)
         {
        	 //if(c[i]==c[j])
        	 if(strr.charAt(i)==strr.charAt(j))
    		 {
        		 System.out.println("duplicate values oare :::::::::"+c[j]);
        	 }
         }	 
     }
     
     HashMap<Character,Integer> h1= new HashMap<Character,Integer>();
     
     for(int i=0;i<strr.length();i++)
     {
    	 if(h1.containsKey(strr.charAt(i)))
    	 {
    		 h1.put(strr.charAt(i), h1.get(strr.charAt(i))+1);
    	 }
    	 else {
    		 h1.put(strr.charAt(i), 1);
    	 }
     }
     System.out.println("Hashmap is :::::::::::"+h1);
     }
     
	}


