package com.zensar.test;

public class Address {
	
	public void getAddress()
	{
		
		System.out.println("getAddress ::::::::::::::");
	}

}
