package com.ibm;

public class FindSumArrayWithoutLoop {

	static int i=0;
	static int count=0;
	public static void main(String[] args) {
		int [] a1={3,7,8,9,2,1,11,4,9,22,45,76};
		//int sum=sum_array(a1);
		//System.out.println(sum);
		
		int total=0;
		for(int i=0;i<a1.length;i++)
		{
			total+=a1[i];
		}
System.out.println("total is ::::::::;;"+total);
	}
	public static int sum_array(int [] b1)
	{
		count++;
		return count==b1.length+1 ? 0:b1[i++]+sum_array(b1);
		
	}
	

}
