package com.ibm.test;

public class CharacterTest {

	public static void main(String[] args) {
		//String input = "véipl$love#? REAL-Tim? Revel?";
	  
	    StringBuilder output = new StringBuilder();
		/*
		 * for (char each : input.toCharArray()) {
		 * 
		 * if (Character.isDigit(each) || Character.isWhitespace(each) ||
		 * Character.isAlphabetic(each)) {
		 * 
		 * output.append(each);
		 * 
		 * } else { output.append(String.format("%04d", (long) each)); }
		 */
	    
	    
	   
	   
	    //System.out.println(output.toString());

	  
	   // }
	    
  String str="véipl$love#? REAL-Tim? Revel?";
	    
	    for(int i=0;i<str.length();i++)
	    {
	    	//System.out.println("=========="+str.charAt(i));
	    	
	    	 if (Character.isDigit(str.charAt(i)) ||
	    			    Character.isWhitespace(str.charAt(i)) || Character.isAlphabetic(str.charAt(i))) {
	    			   
	    			    output.append(str.charAt(i));
	    			   
	    			    }
	    	 else {
	    	
	    	if(str.charAt(i)=='é')
		   {
	    		 output.append(String.format("%04d", (long) str.charAt(i)));
		    	System.out.println("--------------"+String.format("%04d", (long) str.charAt(i)));
		    }
	    	output.append(String.format("%04d", (long) str.charAt(i)));
	    	 }
	    }
	    
	    System.out.println(output.toString());
	    
	}

}
