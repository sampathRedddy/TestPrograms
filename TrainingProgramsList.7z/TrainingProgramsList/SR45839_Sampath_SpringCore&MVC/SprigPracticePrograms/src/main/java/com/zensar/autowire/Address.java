package com.zensar.autowire;

public class Address {
	
	public void getAddress()
	{
		
		System.out.println("getAddress ::::::::::::::");
	}

}
