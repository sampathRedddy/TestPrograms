package com.example.demo;

interface sam{
	 void display() ;
	/*
	 * sam() {} static { System.out.println("fdsfdsf"); }
	 */
}

interface A1
{
	abstract void a1();
	}
interface A2
{
	abstract void a2();
	}

public class interfaceExample implements sam,A1,A2{

	public static void main(String art[])
	{
		System.out.println("hellow inteface::::::::::::");
		
		String s=new String();
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void a2() {
		System.out.println("a2 method is calling");
		
	}

	@Override
	public void a1() {
		// TODO Auto-generated method stub
		System.out.println("a1 method is calling");
	}
}
