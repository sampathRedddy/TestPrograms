package com.ibm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

public class Sortigmapbyvalue {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String ,Integer> map1=new HashMap<String,Integer>();
		map1.put("rahul", 10);
		map1.put("raj", 8);
		map1.put("pahul", 5);
		map1.put("rohitl", 3);
		map1.put("nitesh", 2);
		map1.put("chiru", 9);
	  System.out.println(map1);
	  
	  TreeMap<String,Integer> map2=new TreeMap<String,Integer>(map1);
	  System.out.println(map2);
	Set<Entry<String,Integer>> set=  map1.entrySet();
	System.out.println(set);
//	List<Entry<String,Integer>> list1=new ArrayList<Entry<String,Integer>>(set);
//	Collections.sort(list1, new Comparator<Map.Entry<String, Integer>>(){
//		public int compare(Map.Entry<String, Integer> entry1,Map.Entry<String, Integer> entry2)
//		{
//			return entry1.getValue()-entry2.getValue();
//		}
//	
//	});
//	System.out.println(list1);
	List<Map.Entry<String, Integer>> list1=new ArrayList<Map.Entry<String,Integer>> (set);
	int f=Collections.max(map1.values());
	System.out.println("max value"+f);
	Collections.sort(list1, new Comparator<Map.Entry<String, Integer>>(){

		@Override
		public int compare(Entry<String, Integer> entry1, Entry<String, Integer> entry2) {
			
			return entry1.getValue()-entry2.getValue();
		}
		
		
	});
	System.out.println(list1);
	
	
	
		

	}

}


	
	
	
	

