package com.zensar.component;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = { "com.zensar.component" })
public class BeanFile {

	
	/*
	 * @Bean(name="profile") public Profile getProfile() { return new Profile(); }
	 * 
	 * @Bean(name="student") public Student getProfile1() { return new Student(); }
	 * 
	 * @Bean(name="person") public Person getProfile12() { return new Person(); }
	 */
}
