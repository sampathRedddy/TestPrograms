package com.zensar.spring;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AppController {
	
	//AppModel appModel;
	@Autowired
	@Qualifier(value = "calculatorFile")
	CalculatorInterface calInterface;
	
	@Autowired
	@Qualifier(value = "calculatorFile1Impl")
	CalculatorInterface calInterface1;
	

	@RequestMapping(value = "/" , method= RequestMethod.GET)
	@ResponseBody
	public String display()
	{
		
		//System.out.println("FirstApplicatin :::::::::");
		return "Sampath Reddy";
	}
	
	@RequestMapping(value = "/home/{name}" , method= RequestMethod.GET)
	//@ResponseBody
	public String display1(@PathVariable("name") String name1,Model model)
	{
		System.out.println("input stging ::::::::::"+name1);
		
		model.addAttribute("modelparam",name1);
		
		return "testPage";
	}
	
	
	@RequestMapping(value = "/welcome/{cal1}/{cal2}/", method = RequestMethod.GET)
	public String printWelcome(@PathVariable("cal1") int cal1, @PathVariable("cal2") int cal2, Model model) {
		System.out.println("cal1 : " + cal1);
		System.out.println("cal2 : " + cal2);
		
		
		int results= calInterface.add(cal1, cal2);
		model.addAttribute("modelparam",results);
		return "testPage";
	}
	
	@RequestMapping(value = "/welcome/{cal1}/{cal2}/{cal3}", method = RequestMethod.GET)
	public String printWelcome(@PathVariable("cal1") int cal1, @PathVariable("cal2") int cal2,@PathVariable("cal2") int cal3, Model model) {
		System.out.println("cal1 : " + cal1);
		System.out.println("cal2 : " + cal2);
		System.out.println("cal3 : " + cal3);
		
		int results1= calInterface1.add(cal1, cal2,cal3);
		model.addAttribute("calculatorParam",results1);
		return "calculatorPage";
	}
	
	
	
	@RequestMapping(value = "/home1/{name}" , method= RequestMethod.GET)
	//@ResponseBody
	public String testMethod(@Valid @PathVariable("name") int name1)
	{
		System.out.println("input stging ::::::::::"+name1);
		
		//model.addAttribute("modelparam",name1);
		
		return "testPage";
	}
	
	
	@RequestMapping(value = "/loginModel" , method= RequestMethod.GET)
	//@ResponseBody
	public String testMethod(@Valid LoginModelFile loginModel , BindingResult results,Model model)
	{
		
		String loginID=loginModel.getLoginID();
		String password=loginModel.getPassword();
		
	    System.out.println("LoginID:::::"+loginID);	
	    System.out.println("Password:::::"+password);	
		
	
	if (results.hasErrors())
	{
		//System.out.println("input stging ::::::::::"+results.getFieldError().getField());
		
		String loginIDResult=results.getFieldError().getField();
		String loginIDMessage=results.getFieldError().getDefaultMessage();
		
		
		model.addAttribute("loginStatus","loginPage failed with field : " +  loginIDResult + " \nerror = "+ loginIDMessage);
		
		
		
		
		/*
		
		
		System.out.println(loginIDResult);
		
		//return "testPage";
		if(loginIDResult=="loginID" && loginIDResult=="password")
		{
			model.addAttribute("loginError",loginID);
		}
		return "ErrorPage";*/
	}
	
	else
	{
		model.addAttribute("loginStatus","loginPage Sucess");
	}
	
	//phoneNo.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}"))
		//model.addAttribute("modelparam",name1);
		
	return "testPage";
	}
	
	
}
