import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.SystemEnvironmentPropertySource;

public class HelloWorld {

	public static void main(String arg[])
	{
		//System.out.println("hello world:::::::");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beansConfig.xml");
		/*HelloBean hello=(HelloBean) context.getBean("hellobean");
		
	    System.out.println("Object is :::::::::::::"+hello);
	    System.out.println("Values are ::::::::"+hello.getName() +"id::::::::"+hello.getId());
	    
	     hello.getSt1().display();
	    
	     System.out.println("list values are :::::::::::::"+hello.getStudentAddress());
	     System.out.println("list values are :::::::::::::"+hello.getStudentCity());*/
	     
	     InitClass init=(InitClass) context.getBean("initSingle");
	     
	     
	     
	     
	     
	}
}
