package com.example.demo;
@FunctionalInterface
interface lmdInterfdace
{
public String display();
default void message()
{}
}
public class LamdaExample {

	public static void main(String[] args) {
		lmdInterfdace lmd =	()-> {
			return "hello lamda example";
		};
       System.out.println(lmd.display());  
	}

}
