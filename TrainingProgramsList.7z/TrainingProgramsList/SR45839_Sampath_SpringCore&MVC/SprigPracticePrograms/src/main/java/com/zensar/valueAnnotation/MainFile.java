package com.zensar.valueAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainFile {

	public static void main(String arg[])
	
	{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/zensar/valueAnnotation/beanValueConfig.xml");
		BeanFile obj= context.getBean("beanFile",BeanFile.class);
		obj.display();
	}
}
