package com.zensar.spring;

 abstract class AbstractClass {


	 abstract int add(int a,int b) ;
	 abstract int add(int a,int b,int c);
	
}
