package com.zensar.spring;

import org.springframework.stereotype.Component;

@Component
public class CalculatorFile1Impl implements CalculatorInterface{

	@Override
	public int add(int a, int b) {
		
		return 0;
	}

	@Override
	public int add(int a, int b, int c) {
		
		return a+b+c;	
	}

}
