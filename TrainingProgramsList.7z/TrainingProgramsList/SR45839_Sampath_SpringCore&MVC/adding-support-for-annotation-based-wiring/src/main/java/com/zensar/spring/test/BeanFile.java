package com.zensar.spring.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanFile {

	@Bean(name="logger")
	public Logger logMethod()
	{
		return new Logger();
	}
	@Bean(name="consoleWriter")
	public ConsoleWriter ConsoleWriterMethod()
	{
		return new ConsoleWriter();
	}
	@Bean(name="fileWriter")
	public FileWriter lFileWriterMethod()
	{
		return new FileWriter();
	}
	
}
