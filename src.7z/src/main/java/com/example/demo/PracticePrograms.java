package com.example.demo;

import java.util.HashMap;
import java.util.Map;

public class PracticePrograms {

	public static void main(String[] args) {
		
		//Reverse String
		String str="sampathReddy";
		String reverse="";
		System.out.println("string length is :::::::"+str.length()+"====="+str.charAt(0));
		for(int i=str.length()-1;i>=0;i--) {
			//System.out.println("reverse string is :::::::"+str.charAt(i));
			reverse=reverse+str.charAt(i);
		}
		System.out.println("reverse string is ::::::::"+reverse);
		String str1="sampathsasatsys";
		StringBuffer sb=new StringBuffer(str1);
		System.out.println("Stringbuffer reverse is:"+sb.reverse());;
		

		int x=23;
		int y=45;
		System.out.println("Before Swapping\nx = "+x+"\ny = "+y);
	
		      x = x + y;
		
		      y = x - y;
		
		      x = x - y;
		      System.out.println("After Swapping without third variable\nx = "+x+"\ny = "+y);
		      
		      
		      HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		      for(int i=0;i<str1.length();i++)
		      {
		    	  if(hm.containsKey(str1.charAt(i)))
		    			  {
		    		  hm.put(str1.charAt(i), hm.get(str1.charAt(i))+1);
		    			  }
		    	  else {
		    		  hm.put(str1.charAt(i), 1);
		    	  }
		      }
		      
		      int maxKey=0;
		      char c = 0;
		    for(Map.Entry mp : hm.entrySet())
		    {
		    	//System.out.println(mp.getKey()+"==="+mp.getValue());
		    	
		    	if((Integer)mp.getValue()>1)
		    	{
		    		System.out.println("max value ::::::::"+mp.getKey()+"===="+mp.getValue());
		    	}
		    	
		    	if(maxKey < (Integer)mp.getValue())
		    	{
		    		maxKey=(Integer)mp.getValue();
		    		c=(char) mp.getKey();
		    	}
		    }
		    System.out.println("max key is :::::"+maxKey+"--"+c);
		    
		    
		    String rstr="chintucnt";
		    String fstr = new String();
	for(int i=0;i<rstr.length();i++)
	{
		if(fstr.indexOf(rstr.charAt(i))<0)
		{
			fstr=fstr+rstr.charAt(i);
		}
	}
	System.out.println("Final string is ::::"+fstr);
	
	for(int i=0;i<rstr.length();i++)
	{
		for(int j=i+1;j<rstr.length();j++)
		{
			if(rstr.charAt(i)== rstr.charAt(j))
			{
				System.out.println("duplicate character are :::::::"+rstr.charAt(j));
			}
		}
	}
	
	
	int arr[] = { 14, 46, 47, 94, 94, 52, 86, 36, 94, 89 };
	
	        int largest = arr[0];
	        int secondLargest = arr[0];
	        System.out.println("The given array is:");
	        for (int i = 0; i < arr.length; i++)
	        {
	            System.out.print(arr[i] + "\t");
	        }
	        for (int i = 0; i < arr.length; i++)
	        {
	            if (arr[i] > largest)
	            {
	                secondLargest = largest;
	                largest = arr[i];
	            }
	            else if (arr[i] > secondLargest && arr[i] != largest)	
	            {
	                secondLargest = arr[i];
	            }
	        }
	        System.out.println("\nSecond largest number is:" + secondLargest);
	
	}

}
