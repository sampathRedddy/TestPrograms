package com;
//input=int [] a={4,5,6,12,8,9,10,11};
//output=int [] a={12,12,12,11,11,11,-1};

public class Replacearrayvaluewithrightmaxwithoutloop {

	static int count=0;
	static int maxsum=0;
	public static void main(String[] args) {
		int [] a={4,5,6,12,8,9,10,11};
		int[] b=replace_arraymax(a,count,maxsum);

	}
public static int[] replace_arraymax(int[]a,int count,int maxsum)
{
	count++;
	return (int[]) (count==a.length ? a[count]=-1:max_sum(a,count,a.length-1)>a[count]?replace_arraymax(a,count,max_sum(a,count,a.length-1)):max_sum(a,count,a.length-1)==a[count]?replace_arraymax(a,count,max_sum(a,count+1,a.length-1)):replace_arraymax(a,count,max_sum(a,count+1,a.length-1)));
}
public static int max_sum(int[]a,int i,int n)
{
	
maxsum=a[i];
i++;
return i==n?maxsum:a[i]>maxsum?max_sum(a,i,n):i++;
}
}
