import java.util.List;
import java.util.Map;
import java.util.Set;

public class HelloBean {

	private String Name;
	
    private int id;
    
    private boolean gender;
    
    Set studentAddress;
    Map studentCity;
    
    
    HelloBean()
    {
    	System.out.println("HelloBean default constructor");
    }
    
    public Map getStudentCity() {
		return studentCity;
	}



	public void setStudentCity(Map studentCity) {
		this.studentCity = studentCity;
	}


	Student st1;
    
	
	public Student getSt1() {
		return st1;
	}



	public Set getStudentAddress() {
		return studentAddress;
	}



	public void setStudentAddress(Set studentAddress) {
		this.studentAddress = studentAddress;
	}



	public void setSt1(Student st1) {
		this.st1 = st1;
	}



	public boolean isGender() {
		return gender;
	}


	
	public void setGender(boolean gender) {
		this.gender = gender;
	}


	public int getId() {
		return id;
	}

	
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		
	
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	
	@Override
	public String toString() {
		return "HelloBean [Name=" + Name + ", id=" + id + "]";
	}

	
	
	public void initMethod()
	{
		
		System.out.println("initMethod :::::::::::::");
	}

	
	
	
	
}
