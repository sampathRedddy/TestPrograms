package com.ibm;

import java.util.ArrayList;
import java.util.Collections;

public class PracticeIBMPrograms {

	public static void main(String[] args) {
		
		int a[]= {1,6,4,2,5};
		System.out.println(arrayofSum(a,0));
		System.out.println(reverseString("sampath"));
        System.out.println(findMissingNumber(a));
        
        
        ArrayList<Integer> al=new ArrayList<Integer>();
        al.add(1);
        al.add(6);
        al.add(3);
        al.add(5);
        
        Collections.sort(al);
        Collections.max(al);
        System.out.println("al is ::::::;"+al);
        System.out.println(Collections.max(al));
	}
	public static int arrayofSum(int a[],int index)
	{
		
		if(a.length<=index)
		{
			return 0;
		}
		else
		{	
			return a[index]+arrayofSum(a,index+1);
		}
	}
	public static String reverseString(String s)
    {
    	if(s.length()==0)
    	{
    		return " ";
    	}
    	else {
    		
    	return s.charAt(s.length()-1)+reverseString(s.substring(0, s.length()-1));
    	}
    }
    
    public static int findMissingNumber(int a[])
    {
    	int length=a.length;
    	int total=(length+1)*(length+2)/2;
    	
    	for(int i=0;i<a.length;i++)
    	{
    		total -= a[i];
    	}
    	
    	return total;
    }
    
}
